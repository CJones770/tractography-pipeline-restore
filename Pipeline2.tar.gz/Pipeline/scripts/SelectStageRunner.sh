#!/bin/bash

#./Stage1_Runner.sh
#./Stage2_Runner.sh
./Stage3_Runner.sh
./Stage4_Runner.sh
