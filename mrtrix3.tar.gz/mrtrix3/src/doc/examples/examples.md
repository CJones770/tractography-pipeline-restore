Example applications      {#examples}
====================

The following examples provide skeleton commands to perform different types of
operations, which can be used as a starting point for new applications.

@subpage example_per_datum_processing

@subpage example_per_datum_multithreaded_processing

@subpage example_per_voxel_multithreaded_4D_processing



