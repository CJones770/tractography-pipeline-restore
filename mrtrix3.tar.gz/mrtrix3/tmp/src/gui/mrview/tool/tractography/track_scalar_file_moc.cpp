/****************************************************************************
** Meta object code from reading C++ file 'track_scalar_file.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../../src/gui/mrview/tool/tractography/track_scalar_file.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'track_scalar_file.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MR__GUI__MRView__Tool__TrackScalarFileOptions[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      52,   46,   47,   46, 0x0a,
      92,   46,   47,   46, 0x0a,
     143,   46,   46,   46, 0x08,
     166,   46,   46,   46, 0x08,
     190,   46,   46,   46, 0x08,
     212,   46,   47,   46, 0x08,
     251,  244,   46,   46, 0x08,
     280,  244,   46,   46, 0x08,
     309,   46,   46,   46, 0x08,
     341,   46,   46,   46, 0x08,
     373,   46,   46,   46, 0x08,
     397,   46,   46,   46, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MR__GUI__MRView__Tool__TrackScalarFileOptions[] = {
    "MR::GUI::MRView::Tool::TrackScalarFileOptions\0"
    "\0bool\0open_intensity_track_scalar_file_slot()\0"
    "open_intensity_track_scalar_file_slot(std::string)\0"
    "show_colour_bar_slot()\0select_colourmap_slot()\0"
    "on_set_scaling_slot()\0"
    "threshold_scalar_file_slot(int)\0unused\0"
    "threshold_lower_changed(int)\0"
    "threshold_upper_changed(int)\0"
    "threshold_lower_value_changed()\0"
    "threshold_upper_value_changed()\0"
    "invert_colourmap_slot()\0reset_intensity_slot()\0"
};

void MR::GUI::MRView::Tool::TrackScalarFileOptions::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TrackScalarFileOptions *_t = static_cast<TrackScalarFileOptions *>(_o);
        switch (_id) {
        case 0: { bool _r = _t->open_intensity_track_scalar_file_slot();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 1: { bool _r = _t->open_intensity_track_scalar_file_slot((*reinterpret_cast< std::string(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 2: _t->show_colour_bar_slot(); break;
        case 3: _t->select_colourmap_slot(); break;
        case 4: _t->on_set_scaling_slot(); break;
        case 5: { bool _r = _t->threshold_scalar_file_slot((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 6: _t->threshold_lower_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->threshold_upper_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->threshold_lower_value_changed(); break;
        case 9: _t->threshold_upper_value_changed(); break;
        case 10: _t->invert_colourmap_slot(); break;
        case 11: _t->reset_intensity_slot(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MR::GUI::MRView::Tool::TrackScalarFileOptions::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MR::GUI::MRView::Tool::TrackScalarFileOptions::staticMetaObject = {
    { &QGroupBox::staticMetaObject, qt_meta_stringdata_MR__GUI__MRView__Tool__TrackScalarFileOptions,
      qt_meta_data_MR__GUI__MRView__Tool__TrackScalarFileOptions, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MR::GUI::MRView::Tool::TrackScalarFileOptions::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MR::GUI::MRView::Tool::TrackScalarFileOptions::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MR::GUI::MRView::Tool::TrackScalarFileOptions::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MR__GUI__MRView__Tool__TrackScalarFileOptions))
        return static_cast<void*>(const_cast< TrackScalarFileOptions*>(this));
    if (!strcmp(_clname, "DisplayableVisitor"))
        return static_cast< DisplayableVisitor*>(const_cast< TrackScalarFileOptions*>(this));
    return QGroupBox::qt_metacast(_clname);
}

int MR::GUI::MRView::Tool::TrackScalarFileOptions::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGroupBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
