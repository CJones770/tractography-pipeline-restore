/****************************************************************************
** Meta object code from reading C++ file 'fixel.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../../src/gui/mrview/tool/fixel/fixel.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fixel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MR__GUI__MRView__Tool__Fixel[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      30,   29,   29,   29, 0x08,
      48,   29,   29,   29, 0x08,
      69,   67,   29,   29, 0x08,
     112,   29,   29,   29, 0x08,
     139,  128,   29,   29, 0x08,
     170,  162,   29,   29, 0x08,
     198,  188,   29,   29, 0x08,
     223,   29,   29,   29, 0x08,
     248,   29,   29,   29, 0x08,
     270,   29,   29,   29, 0x08,
     295,   67,   29,   29, 0x08,
     349,   29,   29,   29, 0x08,
     374,   29,   29,   29, 0x08,
     396,  128,   29,   29, 0x08,
     430,  423,   29,   29, 0x08,
     459,  423,   29,   29, 0x08,
     488,   29,   29,   29, 0x08,
     520,   29,   29,   29, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MR__GUI__MRView__Tool__Fixel[] = {
    "MR::GUI::MRView::Tool::Fixel\0\0"
    "fixel_open_slot()\0fixel_close_slot()\0"
    ",\0toggle_shown_slot(QModelIndex,QModelIndex)\0"
    "hide_all_slot()\0is_checked\0"
    "on_checkbox_slot(bool)\0opacity\0"
    "opacity_slot(int)\0thickness\0"
    "line_thickness_slot(int)\0"
    "length_multiplier_slot()\0length_type_slot(int)\0"
    "threshold_type_slot(int)\0"
    "selection_changed_slot(QItemSelection,QItemSelection)\0"
    "colour_changed_slot(int)\0on_set_scaling_slot()\0"
    "on_set_tracking_slot(bool)\0unused\0"
    "threshold_lower_changed(int)\0"
    "threshold_upper_changed(int)\0"
    "threshold_lower_value_changed()\0"
    "threshold_upper_value_changed()\0"
};

void MR::GUI::MRView::Tool::Fixel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        Fixel *_t = static_cast<Fixel *>(_o);
        switch (_id) {
        case 0: _t->fixel_open_slot(); break;
        case 1: _t->fixel_close_slot(); break;
        case 2: _t->toggle_shown_slot((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< const QModelIndex(*)>(_a[2]))); break;
        case 3: _t->hide_all_slot(); break;
        case 4: _t->on_checkbox_slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->opacity_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->line_thickness_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->length_multiplier_slot(); break;
        case 8: _t->length_type_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->threshold_type_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->selection_changed_slot((*reinterpret_cast< const QItemSelection(*)>(_a[1])),(*reinterpret_cast< const QItemSelection(*)>(_a[2]))); break;
        case 11: _t->colour_changed_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_set_scaling_slot(); break;
        case 13: _t->on_set_tracking_slot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->threshold_lower_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->threshold_upper_changed((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->threshold_lower_value_changed(); break;
        case 17: _t->threshold_upper_value_changed(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MR::GUI::MRView::Tool::Fixel::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MR::GUI::MRView::Tool::Fixel::staticMetaObject = {
    { &Base::staticMetaObject, qt_meta_stringdata_MR__GUI__MRView__Tool__Fixel,
      qt_meta_data_MR__GUI__MRView__Tool__Fixel, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MR::GUI::MRView::Tool::Fixel::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MR::GUI::MRView::Tool::Fixel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MR::GUI::MRView::Tool::Fixel::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MR__GUI__MRView__Tool__Fixel))
        return static_cast<void*>(const_cast< Fixel*>(this));
    if (!strcmp(_clname, "ColourMapButtonObserver"))
        return static_cast< ColourMapButtonObserver*>(const_cast< Fixel*>(this));
    if (!strcmp(_clname, "DisplayableVisitor"))
        return static_cast< DisplayableVisitor*>(const_cast< Fixel*>(this));
    return Base::qt_metacast(_clname);
}

int MR::GUI::MRView::Tool::Fixel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Base::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
