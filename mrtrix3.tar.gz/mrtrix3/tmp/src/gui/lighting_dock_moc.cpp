/****************************************************************************
** Meta object code from reading C++ file 'lighting_dock.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/gui/lighting_dock.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'lighting_dock.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MR__GUI__LightingSettings[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      33,   27,   26,   26, 0x09,
      61,   27,   26,   26, 0x09,
      89,   27,   26,   26, 0x09,
     118,   27,   26,   26, 0x09,
     134,   26,   26,   26, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_MR__GUI__LightingSettings[] = {
    "MR::GUI::LightingSettings\0\0value\0"
    "ambient_intensity_slot(int)\0"
    "diffuse_intensity_slot(int)\0"
    "specular_intensity_slot(int)\0"
    "shine_slot(int)\0light_position_slot()\0"
};

void MR::GUI::LightingSettings::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        LightingSettings *_t = static_cast<LightingSettings *>(_o);
        switch (_id) {
        case 0: _t->ambient_intensity_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->diffuse_intensity_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->specular_intensity_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->shine_slot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->light_position_slot(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MR::GUI::LightingSettings::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MR::GUI::LightingSettings::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_MR__GUI__LightingSettings,
      qt_meta_data_MR__GUI__LightingSettings, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MR::GUI::LightingSettings::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MR::GUI::LightingSettings::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MR::GUI::LightingSettings::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MR__GUI__LightingSettings))
        return static_cast<void*>(const_cast< LightingSettings*>(this));
    return QFrame::qt_metacast(_clname);
}

int MR::GUI::LightingSettings::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
