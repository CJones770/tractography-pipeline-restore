
namespace MR {
  namespace App {
    const char* mrtrix_version = "3.0.3-68-ged955840";
    const char* build_date = __DATE__;
  }
}
